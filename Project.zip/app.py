import os
from flask import Flask,redirect,url_for,flash
from flask import render_template
from flask import request,session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_,and_
import numpy as np
import matplotlib.pyplot as plt

current_dir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///" + os.path.join(current_dir, "ticketnew.sqlite3")
db = SQLAlchemy()
db.init_app(app)
app.app_context().push()
app.secret_key = 'super secret key'

class Venue(db.Model):
	venue_id = db.Column(db.Integer, primary_key = True)
	venue_name =  db.Column(db.String, nullable=False, unique=True)
	venue_place =  db.Column(db.String, nullable=False)
	venue_location =  db.Column(db.String, nullable=False)
	venue_capacity =  db.Column(db.Integer, nullable=False)
	shows = db.relationship("Show", secondary="association", backref="venues")

class Show(db.Model):
	show_id = db.Column(db.Integer, primary_key = True)
	show_name =  db.Column(db.String, nullable=False)
	show_rating =  db.Column(db.String, nullable=False)
	show_timing  = db.Column(db.String, nullable=False)
	show_tags =  db.Column(db.String, nullable=False)
	show_price =  db.Column(db.Integer, nullable=False)
	uix_1 = db.UniqueConstraint('show_id','show_name','show_timing')

class Tickets(db.Model):
	venue_id = db.Column(db.Integer, primary_key = True)
	show_id = db.Column(db.Integer, primary_key = True)
	ven_capacity =  db.Column(db.Integer, nullable=False)
	seats_booked =  db.Column(db.Integer, nullable=False, default=0)
	avail_seats =  db.column_property(ven_capacity - seats_booked)

class Association(db.Model):
	venue_id = db.Column(db.Integer, db.ForeignKey("venue.venue_id"), primary_key=True)
	show_id = db.Column(db.Integer, db.ForeignKey("show.show_id"), primary_key=True)

class Rating(db.Model):
	rate_id = db.Column(db.Integer, primary_key=True)
	show_name = db.Column(db.String, nullable=False)
	rating = db.Column(db.Float,nullable=False)

class User(db.Model):
	user_id = db.Column(db.Integer, primary_key = True)
	user_name = db.Column(db.String,nullable=False, unique = True)
	email = db.Column(db.String, unique=True)
	password = db.Column(db.String,nullable=False)
	bookings = db.relationship("Show",secondary="booking",backref="users")

class Booking(db.Model):
	user_id = db.Column(db.Integer, db.ForeignKey("user.user_id"), primary_key = True)
	show_id = db.Column(db.Integer, db.ForeignKey("show.show_id"), primary_key=True)

@app.route('/',methods = ['POST','GET'])
def landing_page():
	if request.method == 'POST':
		user_ans = request.form['option']
		if user_ans == 'Admin':
			return redirect('/adminlogin')
		return redirect('/userlogin')
	return render_template('Landing.html')

@app.route("/userlogin",methods=['POST','GET'])
def user_login():
	if request.method == 'POST':
		uname = request.form["username"]
		upassw = request.form["password"]
		session["uname"]=uname
		valid = User.query.filter_by(user_name = uname,password = upassw).first()
		if valid==None:
			error = "Invalid credentials"
			return render_template("UserLogin.html",error=error)
		else:
			rel = Show.query.all()
			seats = Tickets.query.all()
			return render_template("UserDashboard.html",rel=rel,seats=seats,uname = uname)
	return render_template('UserLogin.html')

@app.route('/adminlogin',methods = ['POST','GET'])
def admin_login():
	if request.method == 'POST':
		name = request.form["aname"]
		passw = request.form["passw1"]
		session["name"]=name
		if name=="Admin123" and passw=="Appdev":
			venue_list = Venue.query.all()
			show_list = Show.query.all()
			venue_count = len(venue_list)
			if venue_count < 1:
 				return render_template('AdminDashboard.html',name = name)
			else:
				return render_template('AdminDashboard2.html',all = venue_list,rel=show_list,name = name)
		else:
			error = "To Login Admin webpage, enter the correct admin credentials"
			return render_template("AdminLogin.html",error=error)
	return render_template('AdminLogin.html')

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        register = User(user_name = username, email = email, password = password)
        db.session.add(register)
        db.session.commit()
        return redirect('/userlogin')
    return render_template("register.html")

@app.route("/udashboard",methods=["GET", "POST"])
def udashboard():
	uname = session.get("uname",None)
	show_list = Show.query.all()
	seats = Tickets.query.all()
	if request.method == "POST":
		searchtext = request.form['searchtext']
		show1 = Show.query.filter(or_(Show.show_name.like('%' + searchtext + '%'), Show.show_tags.like('%' + searchtext + '%'), Show.show_rating > searchtext)).all()
		if not show1:
			ven1 = Venue.query.filter(Venue.venue_location.like('%' + searchtext + '%')).all()
			show2 = []
			for i in ven1:
				venue_id = i.venue_id
				sh = Show.query.filter(Show.venues.any(venue_id=venue_id))	
				for j in sh:
					show2.append(j.show_id)	
			sh2 = Show.query.filter(Show.show_id.in_(show2)).all()	

			return render_template("UserDashboard.html",rel=sh2,seats=seats,uname = uname)
		return render_template('UserDashboard2.html',rel=show1,seats=seats,uname=uname)
	return render_template('UserDashboard.html',rel=show_list,seats=seats,uname=uname)

@app.route("/venuedetails/<int:venue_id>",methods=['POST','GET'])
def venuedetails(venue_id):
	uname = session.get("uname",None)
	ven=Venue.query.filter_by(venue_id =venue_id).first()
	return render_template("VenueDetails.html",all=ven,uname = uname)	

@app.route("/bookshow/<int:show_id>/<int:venue_id>",methods=['POST','GET'])
def bookshow(show_id,venue_id):
	uname = session.get("uname",None)
	sh2 = Show.query.filter_by(show_id=show_id).first()
	for value in Show.query.with_entities(Show.show_price).filter_by(show_id=show_id).first():
		sh_price = value
	ven2 = Venue.query.filter_by(venue_id=venue_id).first()
	for value in Tickets.query.with_entities(Tickets.avail_seats).filter_by(show_id=show_id,venue_id=venue_id).first():
		seats = value
	for value in Tickets.query.with_entities(Tickets.seats_booked).filter_by(show_id=show_id,venue_id=venue_id).first():
		seats_booked = value
	if request.method == 'POST':
		No_of_bookings = request.form["no_of_bookings"]
		session["bcount"]=No_of_bookings
		if int(No_of_bookings) > int(seats):
			error = "Enter the number of tickets based on available tickets"	
			return render_template('bookings.html',sh2=sh2,ven2=ven2,uname=uname,seats=seats,error=error)
		Total_price = int(sh_price) * int(No_of_bookings) 
		seats = int(seats) - int(No_of_bookings)
		t_obj = Tickets.query.filter_by(show_id=show_id,venue_id=venue_id).first()
		t_obj.seats_booked = int(No_of_bookings) + int(seats_booked)
		db.session.commit()
		return render_template('bookings2.html',sh2=sh2,ven2=ven2,uname=uname,seats=seats,num=No_of_bookings,total_price=Total_price)
	return render_template('bookings.html',sh2=sh2,seats=seats,ven2=ven2,uname=uname)

@app.route("/bookupd/<int:show_id>/<int:venue_id>",methods=['POST','GET'])
def bookupd(show_id,venue_id):
	uname = session.get("uname",None)
	sh = Show.query.filter_by(show_id=show_id).first()
	usr = User.query.filter_by(user_name = uname).first()
	user_id = usr.user_id
	usr.bookings.append(sh)
	db.session.commit()
	booking_lists = Show.query.filter(Show.users.any(user_id=user_id))
	return render_template('bookings3.html',uname=uname,all=booking_lists)

@app.route("/booking",methods=['POST','GET'])
def booking():
	uname = session.get("uname",None)
	seat = session.get("bcount",None)
	usr = User.query.filter_by(user_name = uname).first()
	user_id = usr.user_id
	booking_lists = Show.query.filter(Show.users.any(user_id=user_id))
	return render_template('bookings3.html',uname=uname,seat=seat,all=booking_lists)

@app.route("/rate/<show_name>",methods=['POST','GET'])
def rate(show_name):
	uname = session.get("uname",None)
	if request.method == 'POST':
		rating = request.form["rating"]
		r1 = Rating(
			show_name = show_name,
			rating = rating
			)
		db.session.add(r1)
		db.session.commit()
		rel=Show.query.all()
		seats = Tickets.query.all()
		return render_template("UserDashboard.html",rel=rel,seats=seats,uname = uname)		
	return render_template('Rating.html',uname=uname,show_name=show_name)

@app.route("/logout",methods=["GET", "POST"])
def logout():
    return render_template("logout.html")

@app.route("/dashboard",methods=["GET", "POST"])
def dashboard():
	name = session.get("name",None)
	venue_list = Venue.query.all()
	show_list = Show.query.all()
	venue_count = len(venue_list)
	if venue_count < 1:
 		return render_template('AdminDashboard.html',name = name)
	else:
		return render_template('AdminDashboard2.html',all = venue_list,rel=show_list,name = name)

@app.route("/createvenue",methods=['POST','GET'])
def create_venue():
	name = session.get("name",None)
	if request.method == 'POST':
		venue_name = request.form["venuename"]
		place = request.form["place"]
		location = request.form["location"]
		capacity = request.form["capacity"]
		
		ven = Venue(
			venue_name = venue_name,
			venue_place = place,
			venue_location = location,
			venue_capacity = capacity
			)
		db.session.add(ven)
		db.session.commit()		
		all = Venue.query.all()
		show_list = Show.query.all()
		return render_template('AdminDashboard2.html',all = all,rel=show_list,name = name)
	return render_template('CreateVenue.html',name=name)


@app.route("/showdetails/<int:venue_id>",methods=['POST','GET'])
def showdetails(venue_id):
	name = session.get("name",None)
	session["venue_id"]=venue_id
	show_lists = Show.query.filter(Show.venues.any(venue_id=venue_id))
	return render_template('ShowDetails.html',all=show_lists,name=name)

@app.route("/addshow",methods=['POST','GET'])
def addshow():
	name = session.get("name",None)
	venue_id = session.get("venue_id",None)
	all = Show.query.all()
	some = Show.query.filter(Show.venues.any(venue_id=venue_id))
	if request.method == 'POST':
		sh_id = request.form["sh_id"]
		sh = Show.query.filter_by(show_id=sh_id).first()
		ven = Venue.query.filter_by(venue_id=venue_id).first()
		ven.shows.append(sh)
		
		t_obj = Tickets(
			venue_id = venue_id,
			show_id = sh_id,
			ven_capacity = ven.venue_capacity
			)

		db.session.add(t_obj)
		db.session.commit()
		show_lists = Show.query.filter(Show.venues.any(venue_id=venue_id))
		return render_template('ShowDetails.html',all=show_lists,name=name)
	return render_template('ShowDetails3.html',all=all,some=some,name=name)


@app.route("/removeshow/<int:show_id>",methods=['POST','GET'])
def removeshow(show_id):
	name = session.get("name",None)
	venue_id = session.get("venue_id",None)
	if request.method == 'POST':
		ven = Venue.query.filter_by(venue_id=venue_id).first()
		sh = Show.query.filter_by(show_id=show_id).first()
		sh.venues.clear(ven)
		db.session.commit()
		show_lists = Show.query.filter(Show.venues.any(venue_id=venue_id))
		return render_template('ShowDetails.html',all=show_lists,name=name)
	return render_template('delete.html')

@app.route("/updatevenue/<int:venue_id>",methods=['POST','GET'])
def update_venue(venue_id):
	name = session.get("name",None)
	ven1 = Venue.query.filter_by(venue_id=venue_id).first()
	if request.method == 'POST':
		venue_name = request.form["venuename"]
		place = request.form["place"]
		location = request.form["location"]
		capacity = request.form["capacity"]
		ven = Venue.query.filter_by(venue_id=venue_id).first()
		ven.venue_name = venue_name
		ven.venue_place = place
		ven.venue_location = location
		ven.venue_capacity = capacity
		
		db.session.commit()
		
		all = Venue.query.all()
		show_list = Show.query.all()
		return render_template('AdminDashboard2.html',all = all,rel=show_list,name = name)
	return render_template('UpdateVenue.html',name=name,ven1=ven1)

@app.route("/deletevenue/<int:venue_id>",methods=['POST','GET'])
def delete_venue(venue_id):
	name = session.get("name",None)
	ven = Venue.query.filter_by(venue_id=venue_id).first()
	if request.method == 'POST':
		if ven:
			db.session.delete(ven)
			ven.shows.clear()
			db.session.commit()
			all = Venue.query.all()
			show_list = Show.query.all()
			return render_template('AdminDashboard2.html',all = all,rel=show_list,name = name)
		return 'no venues found'
	return render_template('delete.html')

@app.route("/createshow",methods=['POST','GET'])
def createshow():
	name = session.get("name",None)
	if request.method == 'POST':
		show_name = request.form["showname"]
		rating = request.form["rating"]
		timing = request.form["timing"]
		tags = request.form["tags"]
		price = request.form["price"]
		v_id = request.form["v_id"]

		showobj = Show(
			show_name = show_name,
			show_rating = rating,
			show_timing = timing,
			show_tags = tags,
			show_price = price
			)
		ven = Venue.query.get(v_id)
		db.session.add(showobj)
		db.session.commit()


		t_obj = Tickets(
			venue_id = v_id,
			show_id = showobj.show_id,
			ven_capacity = ven.venue_capacity
			)

		db.session.add(t_obj)	
		showobj.venues.append(ven)
		db.session.commit()
		
		show_list = Show.query.all()
		all = Venue.query.all()
		return render_template('AdminDashboard2.html',all = all,rel=show_list,name = name)
	theatre = Venue.query.all()
	return render_template('CreateShow.html',name=name,all=theatre)

@app.route("/updateshow/<int:show_id>",methods=['POST','GET'])
def update_show(show_id):
	name = session.get("name",None)
	sh1 = Show.query.filter_by(show_id=show_id).first()
	if request.method == 'POST':
		show_name = request.form["showname"]
		rating = request.form["rating"]
		timing = request.form["timing"]
		tags = request.form["tags"]
		price = request.form["price"]
		sh = Show.query.filter_by(show_id=show_id).first()
		sh.show_name = show_name
		sh.show_rating = rating
		sh.show_timing = timing
		sh.show_tags = tags
		sh.show_price = price
		
		db.session.commit()
		
		show_list = Show.query.all()
		all = Venue.query.all()
		return render_template('AdminDashboard2.html',all = all,rel=show_list,name = name)
	return render_template('UpdateShow.html',name=name,sh1=sh1)

@app.route("/deleteshow/<int:show_id>",methods=['POST','GET'])
def delete_show(show_id):
	name = session.get("name",None)
	show = Show.query.filter_by(show_id=show_id).first()
	t_show = Tickets.query.filter_by(show_id=show_id).first()
	if request.method == 'POST':
		if show:
			db.session.delete(show)
			db.session.delete(t_show)
			show.venues.clear()
			db.session.commit()
			show_list = Show.query.all()
			all = Venue.query.all()
			return render_template('AdminDashboard2.html',all = all,rel=show_list,name = name)
		return 'no shows found'
	return render_template('deleteshow.html')

@app.route("/Summary",methods=['POST','GET'])
def summary():
	fig, ax= plt.subplots(dpi=1000)
	name = session.get("name",None)
	show_list = Show.query.all()
	x_data = []
	y_data = []
	for row in show_list:
		x_data.append(str(row.show_name))
		y_data.append(float(row.show_rating))
	ax.set_ylabel('Rating')
	ax.set_xlabel('Show_name')
	ax.set_title('Show Ratings')

	plt.yticks(np.arange(0, 5.5, 0.5)) 

	ax.bar(x_data,y_data)

	fig.savefig("static/summary.png", transparent=True,dpi=1000)
	#plt.show()
	plt.close()
	return render_template("Summary.html", name=name)
	
	
if __name__ == '__main__':
  # Run the Flask app
  db.create_all()
  app.run(
    host='0.0.0.0',
    debug=True,
    port=8080
  )


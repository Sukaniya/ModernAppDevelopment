import os
from flask import Flask,redirect,url_for,flash
from flask import render_template
from flask import request,session
from flask_sqlalchemy import SQLAlchemy

current_dir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///" + os.path.join(current_dir, "bloglite.sqlite3")
db = SQLAlchemy()
db.init_app(app)
app.app_context().push()
app.secret_key = 'super secret key'

followers = db.Table('followers',
    db.Column('follower_name', db.String, db.ForeignKey('user.username')),
    db.Column('followed_name', db.String, db.ForeignKey('user.username'))
)

class User(db.Model):
    __tablename__ = 'user'
    user_id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    username = db.Column(db.String, unique=True)
    email = db.Column(db.String, unique=True)
    password = db.Column(db.String)
    Follow = db.Column(db.String, default="FALSE")
    posts = db.relationship("Post", backref='user') #one user many blogs relationship
    #followed = db.relationship("User", secondary=followers,backref="followers")
    followed = db.relationship(
        'User', secondary=followers,
        primaryjoin=(followers.c.follower_name == username),
        secondaryjoin=(followers.c.followed_name == username),
        backref=db.backref('followers', lazy='dynamic'), lazy='dynamic')
    def __init__(self, username, email,password):
        self.username = username
        self.password = password
        self.email = email

    def follow(self,user):    
        if not self.is_following(user):
           self.followers.append(user)

    def unfollow(self, user):
        if self.is_following(user):
           self.followers.remove(user)

    def is_following(self, user):
        return self.followers.filter(followers.c.followed_name == user.username).count() > 0

    def followed_posts(self):
        followed = Post.query.join(
            followers, (followers.c.followed_name == User.username)).filter(
                followers.c.follower_name == self.username)
        own = User.query.filter_by(username=self.username)
        return followed.union(own)
   

    
class Post(db.Model):
    __tablename__ = 'post'
    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    title=db.Column(db.String)
    desc = db.Column(db.String)
    file = db.Column(db.BLOB)
    username = db.Column(db.String, db.ForeignKey('user.username'))

@app.route("/",methods=["GET", "POST"])
def home():
  error=None
  if request.method == "GET":
    return render_template("index.html")
  if request.method == "POST":
    name = request.form["username"]
    passw = request.form["password"]
    session["name"]=name
    valid = User.query.filter_by(username = name,password = passw).first()
    no_of_blogs = Post.query.filter_by(username = name).count()
    if valid==None:
       error = "Invalid credentials"
       return render_template("index.html",error=error)
    else:
       if no_of_blogs < 1:
          return render_template("Dashboard.html",username=name)
       else:
          post=Post.query.filter_by(username=name).all()
          return render_template("Dashboard1.html",username=name,post=post)
@app.route("/logout",methods=["GET", "POST"])
def logout():	
    return render_template("logout.html")

@app.route("/Dashboard",methods=["GET", "POST"])
def Dashboard():
   name = session.get("name",None)
   no_of_blogs = Post.query.filter_by(username = name).count()
   if no_of_blogs < 1:
      return render_template("Dashboard.html",username=name)
   else:
      post=Post.query.filter_by(username=name).all()
      return render_template("Dashboard1.html",username=name,post=post)
def convertToBinaryData(filename):
    # Convert digital data to binary format
    with open(filename, 'rb') as file:
        blobData = file.read()
    return blobData

@app.route("/blog",methods=["GET", "POST"])
def blog():
    name = session.get("name",None)
    if request.method == "POST":
        title = request.form['title']
        desc = request.form['desc']
        filename = request.form['filename']
        image=convertToBinaryData(filename)

        blog = Post(title = title, desc = desc, file = image, username=name)
        db.session.add(blog)
        db.session.commit()
        
        no_of_blogs = Post.query.filter_by(username = name).count()
        if no_of_blogs < 1:
          return render_template("Dashboard.html",username=name)
        else:
          post=Post.query.filter_by(username=name).all()
          return render_template("Dashboard1.html",username=name,post=post)
    return render_template("blog.html")

@app.route("/index",methods=["GET", "POST"])
def index():
    if request.method == "POST":
       name = request.form["username"]
       passw = request.form["password"]
       session["name"]=name
       valid = User.query.filter_by(username = name,password = passw).first()
       no_of_blogs = Post.query.filter_by(username = name).count()
       if valid==None:
          error = "Invalid credentials"
          return render_template("index.html",error=error)
       else:
          if no_of_blogs < 1:
             return render_template("Dashboard.html",username=name)
          else:
             post=Post.query.filter_by(username=name).all()
             return render_template("Dashboard1.html",username=name,post=post)
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        register = User(username = username, email = email, password = password)
        db.session.add(register)
        db.session.commit()

        return redirect(url_for("home"))
    return render_template("register.html")

#Create search function
@app.route("/search", methods=['GET','POST'])
def search():
    name = session.get("name",None)
    if request.method == "POST":
        searchtext = request.form['searchtext']
        user1 = User.query.filter_by(username=name).first()
        users=User.query
        users=users.filter(User.username.like('%' + searchtext + '%'))
        return render_template("Search2.html",users=users,user1=user1,username=name)
    return render_template("search.html",username=name)

def writeTofile(data, filename):
    # Convert binary data to proper format and write it on Hard Disk
    with open(filename, 'wb') as file:
        file.write(data)
    print("Stored blob data into: ", filename, "\n")

#Create Myprofile function
@app.route("/myProfile", methods=['GET','POST'])
def myProfile():
    name = session.get("name",None)
    post=Post.query.filter_by(username=name).all()
    user = User.query.filter_by(username=name).all()
    no_of_blogs = Post.query.filter_by(username = name).count()
    return render_template("myProfile.html",username=name,post=post,user=user,Blogs=no_of_blogs)
    #photo = post.file
    #photopath = r"bloglite"+id+".jfif"
    #writeTofile(photo, photopath)
    #return render_template("myProfile.html",username=name,post=post,image=photopath)
    
@app.route("/Profile/<username>", methods=['GET','POST'])
def Profile(username):
    name = session.get("name",None)
    name = int(name)
    post=Post.query.filter_by(username=username).all()
    user = User.query.filter_by(username=username).all()
    no_of_blogs = Post.query.filter_by(username = username).count()
    return render_template("myProfile.html",username=username,post=post,user=user,Blogs=no_of_blogs)

@app.route('/follow/<username>', methods=['GET','POST'])
def follow(username):
    name = session.get("name",None)
    if request.method == "POST":
        user = User.query.filter_by(username=name).first()
        follower = User.query.filter_by(username=username).first()

        if user is None:
            flash('User {} not found.'.format(username))
            return redirect(url_for('index'))
        if user.username == username:
            flash('You cannot follow yourself!')
            return redirect(url_for('search'))
        follower.follow(user)
        db.session.commit()
        flash('You are following {}!'.format(username))
        return redirect(url_for('search'))
    else:
        return redirect(url_for('Dashboard'))

@app.route('/Unfollow/<username>', methods=['GET','POST'])
def unfollow(username):
    name = session.get("name",None)
    if request.method == "POST":
        user = User.query.filter_by(username=name).first()
        follower = User.query.filter_by(username=username).first()

        if user is None:
            flash('User {} not found.'.format(username))
            return redirect(url_for('index'))
        if user.username == username:
            flash('You cannot unfollow yourself!')
            return redirect(url_for('search'))
        follower.unfollow(user)
        db.session.commit()
        flash('You are not following {}!'.format(username))
        return redirect(url_for('search'))
    else:
        return redirect(url_for('Dashboard'))

if __name__ == '__main__':
  # Run the Flask app
  db.create_all()
  app.run(
    host='0.0.0.0',
    debug=True,
    port=8080
  )
